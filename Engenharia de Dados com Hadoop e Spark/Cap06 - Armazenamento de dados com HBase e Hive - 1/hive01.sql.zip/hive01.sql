create table estudantes
(ID INT,
nome VARCHAR(50),
sobrenome VARCHAR(50),
sexo Char(1),
email VARCHAR(100));


INSERT INTO estudantes
VALUES (100,'Bob','Silva','M','bob@gmail.com');

SELECT * FROM estudantes;

